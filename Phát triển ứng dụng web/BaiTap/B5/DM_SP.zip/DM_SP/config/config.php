<?php

define("HOST", "localhost");
define("DB", "db_shop");
define("USER", "root");
define("PASSWORD", "");
