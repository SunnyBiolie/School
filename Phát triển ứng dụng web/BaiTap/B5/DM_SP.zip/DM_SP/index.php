<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BTVN PHP</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/style.css">
</head>

<body>

  <div class="container">
    <header class="header"></header>
    <div class="row">
      <div class="category col-4">
        <h2>Thêm danh mục</h2>
        <form action="./api/category.php" method="post" target="_self">
          <div class="mb-3">
            <label for="category-name">Tên danh mục</label>
            <input type="text" name="name" id="category-name">
          </div>
          <input type="submit" name="submit" value="Thêm danh mục">
        </form>
      </div>
      <div class="product col-4">
        <h2>Thêm sản phẩm</h2>
        <form class="d-flex flex-column" action="./api/product.php" method="post" enctype="multipart/form-data" target="_self">
          <div class="mb-3">
            <label for="product-category">Danh mục</label>
            <?php require_once "./components/categories.php" ?>
          </div>
          <div class="mb-3">
            <label for="product-name">Tên sản phẩm</label>
            <input type="text" name="name" id="product-name">
          </div>
          <div class="mb-3">
            <label for="product-price">Giá</label>
            <input type="number" name="price" id="product-price" min="100000">
          </div>
          <div class="mb-3">
            <label for="product-desc">Mô tả</label>
            <textarea class="d-block" name="description" id="product-desc" cols="30" rows="5"></textarea>
          </div>

          <div class="mb-3">
            <input type="submit" name="submit" value="Thêm sản phẩm">
            <input type="reset" value="Clear">
          </div>
        </form>
      </div>
      <div class="col-4">
        <div>
          <h4>Danh mục vừa được thêm</h4>
          <ul>
            <?php
            if (isset($_SESSION['categories-name'])) {
              foreach ($_SESSION['categories-name'] as $cat)
                echo "<li>" . $cat . "</li>";
            }
            ?>
          </ul>
        </div>
        <div>
          <h4>Sản phẩm vừa được thêm</h4>
          <div>
            <?php
            if (isset($_SESSION['products-info'])) {
              foreach ($_SESSION['products-info'] as $item) {
                echo "
                  <ul class='border rounded-3'>
                    <li>ID danh mục: " . $item[0] . "</li>
                    <li>Tên sản phẩm: " . $item[1] . "</li>
                    <li>Giá: " . $item[2] . "</li>
                    <li>Mô tả: " . $item[3] . "</li>
                  </ul>  
                ";
              }
            }
            ?>
          </div>
        </div>
      </div>
    </div>
    <footer class="footer"></footer>
  </div>

</body>

</html>