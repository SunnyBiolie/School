<?php require_once __DIR__ . "/../module/db_module.php"; ?>

<select name="categories" id="product-category">
  <?php
  $link = null;
  createConnection($link);

  $result = excuteQuery($link, "select * from `tbl_danhmuc`");
  while ($rows = mysqli_fetch_assoc($result)) {
    echo "<option value='" . $rows['id_danhmuc'] . "'>" . $rows['ten_danhmuc'] . "</option>";
  }

  closeConnection($link, $result);
  ?>
</select>