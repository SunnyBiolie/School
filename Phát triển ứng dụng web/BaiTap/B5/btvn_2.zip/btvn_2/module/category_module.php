<?php

require_once __DIR__ . "/./db_module.php";

function getCategoryNameFromCategoryID($categoryID)
{
  $link = null;
  createConnection($link);

  $query = "select `ten_danhmuc` from `tbl_danhmuc` where `id_danhmuc` = " . $categoryID . ";";
  $result = excuteQuery($link, $query);

  $row = mysqli_fetch_row($result);

  closeConnectionNFreeResult($link, $result);

  return $row[0];
}
