<?php session_start();

require_once "../module/db_module.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  http_response_code(404);
  exit();
}

if ($_POST['name'] && isset($_POST['submit'])) {

  // $link = null;
  // createConnection($link);

  // $query = "insert into `tbl_danhmuc` (ten_danhmuc) values ('" . $_POST['name'] . "')";
  // $result = excuteNonQuery($link, $query);

  if (isset($_SESSION['categories-name'])) {
    array_push($_SESSION['categories-name'], $_POST['name']);
  } else {
    $_SESSION['categories-name'] = array($_POST['name']);
  }

  // closeConnection($link);
}

header('Location: ../index.php');
