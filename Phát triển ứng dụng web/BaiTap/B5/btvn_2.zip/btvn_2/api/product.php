<?php session_start();

require_once '../module/db_module.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  http_response_code(404);
  exit();
}

if ($_POST['categories'] && $_POST['name'] && $_POST['price'] && $_POST['description'] && isset($_POST['submit'])) {
  // $link = null;
  // createConnection($link);

  $name = $_POST['name'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $categoryID = $_POST['categories'];

  // $query = "insert into `tbl_sanpham` (`ten_sanpham`, `mota`, `gia`, `id_danhmuc`) values 
  //           ('" . $name . "', '" . $description . "', " . $price . ", " . $categoryID . ")";
  // excuteNonQuery($link, $query);

  $lastItem = array($categoryID, $name, $price, $description);

  if (isset($_SESSION['products-info'])) {
    array_push($_SESSION['products-info'], $lastItem);
  } else {
    $_SESSION['products-info'] = array($lastItem);
  }

  // closeConnection($link);
}

header('Location: ../index.php');
