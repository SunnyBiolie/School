<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add DM - SP</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <div class="container">
    <header class="header"></header>
    <div class="row">
      <div class="col-7 col-md-8 row">
        <div class="category col-12 col-md-6 mb-3">
          <h2>Thêm danh mục</h2>
          <form action="./api/category.php" method="post" target="_self">
            <div class="mb-3">
              <label for="category-name" class="require">Tên danh mục</label>
              <input type="text" name="name" id="category-name">
            </div>
            <input class="btn btn-secondary" type="submit" name="submit" value="Thêm danh mục">
          </form>
        </div>

        <div class="product col-12 col-md-6 mb-3">
          <h2>Thêm sản phẩm</h2>
          <form class="d-flex flex-column" action="./api/product.php" method="post" enctype="multipart/form-data" target="_self">
            <div class="mb-3">
              <label for="product-category" class="require">Danh mục</label>
              <?php require_once "./components/categories.php" ?>
            </div>
            <div class="mb-3">
              <label for="product-name" class="require">Tên sản phẩm</label>
              <input type="text" name="name" id="product-name">
            </div>
            <div class="mb-3">
              <label for="product-price" class="require">Giá</label>
              <input type="number" name="price" id="product-price" min="100000">
            </div>
            <div class="mb-3">
              <label for="product-desc" class="require">Mô tả</label>
              <textarea class="d-block" name="description" id="product-desc" cols="30" rows="5"></textarea>
            </div>

            <div>
              <input class="btn btn-secondary" type="submit" name="submit" value="Thêm sản phẩm">
              <input class="btn btn-secondary" type="reset" value="Clear Form">
            </div>
          </form>
        </div>
      </div>
      <div class="col-5 col-md-4">
        <div>
          <h4>Danh mục vừa được thêm</h4>
          <?php
          if (isset($_SESSION['categories-name'])) {
            echo "<ul>";
            foreach ($_SESSION['categories-name'] as $cat)
              echo "<li>" . $cat . "</li>";
            echo "</ul>";
          } else echo "<p>Chưa có danh mục nào</p>";
          ?>
        </div>
        <div>
          <h4>Sản phẩm vừa được thêm</h4>
          <div>
            <?php
            // require_once "./module/category_module.php";

            if (isset($_SESSION['products-info'])) {
              foreach ($_SESSION['products-info'] as $item) {
                echo "
                  <ul class='recently-prod-list border rounded-3'>
                    <li><strong>Danh mục:</strong> " . $item[0] . "</li>
                    <li><strong>Sản phẩm:</strong> " . $item[1] . "</li>
                    <li><strong>Giá:</strong> " . $item[2] . "</li>
                    <li><strong>Mô tả:</strong> " . $item[3] . "</li>
                  </ul>  
                ";
              }
            } else echo "<p>Chưa có sản phẩm nào</p>";
            ?>
          </div>
        </div>
      </div>
    </div>
    <footer class="footer"></footer>
  </div>

</body>

</html>