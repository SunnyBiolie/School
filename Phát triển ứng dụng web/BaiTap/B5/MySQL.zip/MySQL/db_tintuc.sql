-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2023 at 04:50 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tintuc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bantin`
--

CREATE TABLE `tbl_bantin` (
  `id_bantin` int(11) NOT NULL,
  `id_danhmuc` int(11) NOT NULL,
  `tieude` varchar(200) NOT NULL,
  `hinhanh` varchar(100) NOT NULL,
  `noidung` text NOT NULL,
  `tukhoa` varchar(200) NOT NULL,
  `nguontin` varchar(100) NOT NULL,
  `like` int(11) NOT NULL,
  `rating` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_bantin`
--

INSERT INTO `tbl_bantin` (`id_bantin`, `id_danhmuc`, `tieude`, `hinhanh`, `noidung`, `tukhoa`, `nguontin`, `like`, `rating`) VALUES
(1, 3, 'Sự thay đổi cách thức mua sắm của khách hàng trong thời kì thương mại điện tử', '\'\'', 'Nội dung', 'mua sắm', '\'\'', 23, 3.7),
(2, 1, 'CMC P&T ký kết hợp tác mô hình đào tạo kép cho sinh viên cao đẳng công nghệ Thủ Đức', '\'\'', 'Nội dung', 'công nghệ', '\'\'', 9, 3.9),
(3, 2, 'Những câu chuyện trong gia đình', '\'\'', 'Nội dung', 'đời sống', '\'\'', 137, 4),
(4, 4, 'Thoái trào tất yêu của Apple trước cạnh tranh trên thị trường smartphone ', '\'\'', 'Nội dung', 'kinh tế', '\'\'', 35, 4.2),
(123, 1, 'Thay đổi sách giáo khoa', '\'\'', 'noi dung moi', 'giáo dục', '\'\'', 0, 2.7),
(124, 5, 'Liệu Samsung sẽ thành công với Galaxy S4 hay sẽ rơi vào tình trạng suy giảm sự tin cậy của nhà đầu tư', '', 'Noi dung', 'tu khoa', '', 1001, 4.5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_binhluan`
--

CREATE TABLE `tbl_binhluan` (
  `id_binhluan` int(11) NOT NULL,
  `tieude` varchar(200) NOT NULL,
  `noidung` text NOT NULL,
  `like` int(11) NOT NULL,
  `thoigian` date NOT NULL,
  `id_bantin` int(11) NOT NULL,
  `id_docgia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_binhluan`
--

INSERT INTO `tbl_binhluan` (`id_binhluan`, `tieude`, `noidung`, `like`, `thoigian`, `id_bantin`, `id_docgia`) VALUES
(1, 'Tieu de', 'Noi dung binh luan', 3, '2023-11-01', 1, 1),
(2, 'Tieu de', '... đó là những bước đi sai lầm và ngốc nghếch của họ ...', 17, '2023-11-01', 4, 2),
(4, 'Tieu de binh luan', 'Noi dung binh luan', 10, '2023-10-29', 124, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dangbai`
--

CREATE TABLE `tbl_dangbai` (
  `id_vietbai` int(11) NOT NULL,
  `id_bantin` int(11) NOT NULL,
  `id_nguoidung` int(11) NOT NULL,
  `thoigian` date NOT NULL,
  `tinhtrang` varchar(50) NOT NULL,
  `ghichu` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_dangbai`
--

INSERT INTO `tbl_dangbai` (`id_vietbai`, `id_bantin`, `id_nguoidung`, `thoigian`, `tinhtrang`, `ghichu`) VALUES
(1, 1, 1, '2023-09-01', 'tinh trang', '\'\''),
(2, 4, 3, '2023-10-02', 'tinh trang', '\'\'');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_danhmuc`
--

CREATE TABLE `tbl_danhmuc` (
  `id_danhmuc` int(11) NOT NULL,
  `ten_danhmuc` varchar(50) NOT NULL,
  `hinhanh` varchar(100) NOT NULL,
  `id_nguoidung` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_danhmuc`
--

INSERT INTO `tbl_danhmuc` (`id_danhmuc`, `ten_danhmuc`, `hinhanh`, `id_nguoidung`) VALUES
(1, 'Giáo dục', '\'\'', 1),
(2, 'Đời sống', '\'\'', 1),
(3, 'Mua sắm', '\'\'', 3),
(4, 'Kinh tế', '\'\'', 3),
(5, 'Công nghệ', '\'\'', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_docgia`
--

CREATE TABLE `tbl_docgia` (
  `id_docgia` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `hoten` varchar(50) NOT NULL,
  `ghichu` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_docgia`
--

INSERT INTO `tbl_docgia` (`id_docgia`, `email`, `password`, `hoten`, `ghichu`) VALUES
(1, 'docgia1@gmail.com', '1234', 'Doc gia 1', NULL),
(2, 'docgia2@gmail.com', '1234', 'Doc gia 2', NULL),
(3, 'docgia3@gmail.com', '1234', 'Doc gia 3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nguoidung`
--

CREATE TABLE `tbl_nguoidung` (
  `id_nguoidung` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `hoten` varchar(50) NOT NULL,
  `bidanh` varchar(50) NOT NULL,
  `dienthoai` varchar(10) NOT NULL,
  `cmnd` varchar(12) NOT NULL,
  `diachi` varchar(100) NOT NULL,
  `ngayvaolam` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_nguoidung`
--

INSERT INTO `tbl_nguoidung` (`id_nguoidung`, `email`, `password`, `hoten`, `bidanh`, `dienthoai`, `cmnd`, `diachi`, `ngayvaolam`) VALUES
(1, 'nguoidung1@gmail.com', '1234', 'Nguyen Van A', 'Aba', '1234567890', '123456789012', 'Tp HCM', '2023-11-01'),
(3, 'user@gmail.com', '1234', 'Nguyen Van B', 'Be', '0987654321', '098765432123', 'Tp HCM', '2023-11-02'),
(7, 'user2@gmail.com', '1234', 'Nguoi dung 2', 'ND2', '1029384756', '019283746547', 'Sai Gon', '2023-10-19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_phanquyen`
--

CREATE TABLE `tbl_phanquyen` (
  `id_phanquyen` int(11) NOT NULL,
  `ten_quyen` varchar(100) NOT NULL,
  `id_nguoidung` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bantin`
--
ALTER TABLE `tbl_bantin`
  ADD PRIMARY KEY (`id_bantin`),
  ADD KEY `id_danhmuc` (`id_danhmuc`);

--
-- Indexes for table `tbl_binhluan`
--
ALTER TABLE `tbl_binhluan`
  ADD PRIMARY KEY (`id_binhluan`),
  ADD KEY `id_bantin` (`id_bantin`),
  ADD KEY `id_docgia` (`id_docgia`);

--
-- Indexes for table `tbl_dangbai`
--
ALTER TABLE `tbl_dangbai`
  ADD PRIMARY KEY (`id_vietbai`),
  ADD KEY `id_nguoidung` (`id_nguoidung`),
  ADD KEY `id_bantin` (`id_bantin`);

--
-- Indexes for table `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  ADD PRIMARY KEY (`id_danhmuc`);

--
-- Indexes for table `tbl_docgia`
--
ALTER TABLE `tbl_docgia`
  ADD PRIMARY KEY (`id_docgia`);

--
-- Indexes for table `tbl_nguoidung`
--
ALTER TABLE `tbl_nguoidung`
  ADD PRIMARY KEY (`id_nguoidung`),
  ADD UNIQUE KEY `cmnd` (`cmnd`);

--
-- Indexes for table `tbl_phanquyen`
--
ALTER TABLE `tbl_phanquyen`
  ADD PRIMARY KEY (`id_phanquyen`),
  ADD KEY `id_nguoidung` (`id_nguoidung`),
  ADD KEY `id_nguoidung_2` (`id_nguoidung`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bantin`
--
ALTER TABLE `tbl_bantin`
  MODIFY `id_bantin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `tbl_binhluan`
--
ALTER TABLE `tbl_binhluan`
  MODIFY `id_binhluan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_dangbai`
--
ALTER TABLE `tbl_dangbai`
  MODIFY `id_vietbai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_danhmuc`
--
ALTER TABLE `tbl_danhmuc`
  MODIFY `id_danhmuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_docgia`
--
ALTER TABLE `tbl_docgia`
  MODIFY `id_docgia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_nguoidung`
--
ALTER TABLE `tbl_nguoidung`
  MODIFY `id_nguoidung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_phanquyen`
--
ALTER TABLE `tbl_phanquyen`
  MODIFY `id_phanquyen` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_bantin`
--
ALTER TABLE `tbl_bantin`
  ADD CONSTRAINT `tbl_bantin_ibfk_1` FOREIGN KEY (`id_danhmuc`) REFERENCES `tbl_danhmuc` (`id_danhmuc`);

--
-- Constraints for table `tbl_binhluan`
--
ALTER TABLE `tbl_binhluan`
  ADD CONSTRAINT `tbl_binhluan_ibfk_1` FOREIGN KEY (`id_docgia`) REFERENCES `tbl_docgia` (`id_docgia`),
  ADD CONSTRAINT `tbl_binhluan_ibfk_2` FOREIGN KEY (`id_bantin`) REFERENCES `tbl_bantin` (`id_bantin`);

--
-- Constraints for table `tbl_dangbai`
--
ALTER TABLE `tbl_dangbai`
  ADD CONSTRAINT `tbl_dangbai_ibfk_1` FOREIGN KEY (`id_nguoidung`) REFERENCES `tbl_nguoidung` (`id_nguoidung`),
  ADD CONSTRAINT `tbl_dangbai_ibfk_2` FOREIGN KEY (`id_bantin`) REFERENCES `tbl_bantin` (`id_bantin`);

--
-- Constraints for table `tbl_phanquyen`
--
ALTER TABLE `tbl_phanquyen`
  ADD CONSTRAINT `tbl_phanquyen_ibfk_1` FOREIGN KEY (`id_nguoidung`) REFERENCES `tbl_nguoidung` (`id_nguoidung`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
