<?php
require_once "./data.php";

$category = $_GET["group"];
if (!$category || !array_key_exists($category, $data)) {
  $keys = array_keys($data);
  header("Location: ./?group=" . $keys[0]);
}

$slectedCategory = $data[$category];
foreach ($slectedCategory as $key => $list) {
  echo "
    <div class='fs-2 bg-danger text-white'>" . $key . "</div>
    <div class='row pb-3'>
  ";
  foreach ($list as $item) {
    echo "
      <div class='col-3 text-center p-3 m-3 bg-info'>
        " . $item . "
      </div>
    ";
  }
  echo "
    </div>
  ";
}
