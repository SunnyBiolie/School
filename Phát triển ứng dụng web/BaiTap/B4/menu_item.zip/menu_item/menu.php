<?php require_once "./data.php"; ?>

<ul>
  <?php
    foreach ($data as $key => $value) {
      echo "<li><a href='?group=".$key."'>".$key."</a></li>";
    }
  ?>
</ul>
