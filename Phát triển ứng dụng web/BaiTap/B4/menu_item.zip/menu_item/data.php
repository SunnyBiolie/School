<?php

$data = array(
  "Laptop" => array(
    "Apple" => array("iMac", "Macbook Pro", "Macbook Air"),
    "Asus" => array("Asus Zenbook", "Asus Transformer Book", "Asus Taichi"),
    "Dell" => array("XPS 11", "XPS 13", "Inspiron 15", "Latitute 15"),
  ),
  "Tablet" => array(
    "Sonny" => array("Sony Tablet Z", "Sony Tablet S"),
    "Samsung" => array("Galaxy Nexus 10", "Galaxy Tab 10.1", "Note 8"),
  ),
  "Smartphone" => array(
    "Apple" => array("iPhone 4", "iPhone 4s", "iPhone 5"),
    "Samsung" => array("Galaxy S3", "Galaxy S4", "Galaxy Note 2"),
    "HTC" => array("HTC One X", "HTC One S", "HTC One"),
  ),
  "Tivi" => array(
    "Sharp" => array("Sharp DX43P", "Sharp TH32D", "Sharp DD72X"),
    "Sony" => array("Sony DT42V", "Sony UT45X", "Sony UT60M")
  )
);
