<?php
  function setPNGHeader() {
    header("Content-Type: image/png");
    header("Expires: -1");
    header("Cache-Control:no-store,no-cache,must-revalidate");
    header("Pragma: no-cache" );
   }

  function makeCaptcha($src, $len){
    $captcha = "";
    for($i=0; $i<$len; $i++)
      $captcha .= substr($src, rand(0, strlen($src)-1), 1);

    return $captcha;
  }
   
  function makePNGCaptcha($captcha) {
    $img = imagecreate(300, 85);

    // define background color
    imagecolorallocate($img, 0, 0, 0);
    
    $textColor = imagecolorallocate($img, 255, 255, 0);
    imagettftext($img, rand(15, 28), rand(-8, 8), rand(10, 100), rand(45, 55), $textColor, "SourceCodePro-Bold.ttf", $captcha);

    imagepng($img);
    imagedestroy($img);
  }
?>