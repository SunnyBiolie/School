var personLists = [
  {
    name: "Phạm Nguyễn Chí Khoa",
    age: 20,
    gender: "male",
    hobby: ["sports", "musics", "films", "games"],
  },
  {
    name: "SunnyBiolie",
    age: 21,
    gender: "male",
    hobby: ["manga", "games"],
  },
];

// JQuery chỉ select được những phần tử hiện có trong DOM
const personName = $("#name");
const age = $("#age");
const gender = $('input[type="radio"][name="gender"]');
const hobby = $('input[type="checkbox"][name="hobby"]');

const submitBtn = $("#submit-btn");

submitBtn.on("click", () => {
  let _name = personName[0].value;
  let _age = age[0].value;
  let _gender;
  let _hobby = [];

  gender.each((index, element) => {
    if (element.checked) {
      _gender = element.value;
      return;
    }
  });

  hobby.each((index, element) => {
    if (element.checked) _hobby.push(element.id);
  });

  personLists.push({
    name: _name,
    age: _age,
    gender: _gender,
    hobby: _hobby,
  });

  renderPersons(personLists);

  resetBtn.click();
});

const resetBtn = $('#info input[type="reset"]');
resetBtn.on("click", function () {
  $(".person").each(function () {
    $(this).removeClass("active");
  });
});

const renderPersons = (personLists) => {
  let renderPlacement = $("#person-lists");
  let renderContent = ``;

  personLists.forEach((person, index) => {
    renderContent += `
      <div class="col mb-3 person" id=${index}>
        <div
          class="text-center border border-light px-3 py-1"
        >
          ${person.name}
        </div>
      </div>
    `;
  });

  renderPlacement[0].innerHTML = renderContent;

  // addClickEventToEachPerson for binding data
  $(".person").on("click", function (e) {
    resetBtn.click();

    personName[0].value = personLists[this.id].name;
    age[0].value = personLists[this.id].age;
    gender.each(function () {
      if (this.value === personLists[e.currentTarget.id].gender) {
        this.checked = true;
        return;
      }
    });
    hobby.each(function () {
      personLists[e.currentTarget.id].hobby.forEach((item) => {
        if (this.id === item) this.checked = true;
      });
    });

    $(".person").each(function () {
      $(this).removeClass("active");
    });
    $(this).addClass("active");
  });
};

renderPersons(personLists);
