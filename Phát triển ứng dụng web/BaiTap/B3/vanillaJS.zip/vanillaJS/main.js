var personLists = [
  // {
  //   name: "Phạm Nguyễn Chí Khoa",
  //   age: 20,
  //   gender: "male",
  //   hobby: ["sports", "musics", "films", "games"],
  // },
];

const pName = document.getElementById("name");
const age = document.getElementById("age");
const gender = document.querySelectorAll('input[type="radio"][name="gender"]');
const hobby = document.querySelectorAll('input[type="checkbox"][name="hobby"]');

const submitBtn = document.getElementById("submit-btn");
// Add click event listener for input#submit[type="button"]
submitBtn.addEventListener(
  "click",
  () => {
    let _name = pName.value;
    let _age = age.value;
    let _gender;
    gender.forEach((item) => {
      if (item.checked === true) {
        _gender = item.value;
      }
    });
    let _hobby = [];
    hobby.forEach((item) => {
      if (item.checked === true) {
        _hobby.push(item.id);
      }
    });
    console.log(_name, _age, _gender, _hobby);

    personLists.push({
      name: _name,
      age: _age,
      gender: _gender,
      hobby: _hobby,
    });

    removeEventToPerson();
    // Call after add person to list
    renderPersons(personLists);
  },
  false
);

function bindingData(person) {
  // Reset form info
  let reset = document.querySelector('#info input[type="reset"]');
  reset.click();

  // Binding data from personLists to form
  pName.value = personLists[person.id].name;
  age.value = personLists[person.id].age;
  gender.forEach((item) => {
    if (item.value === personLists[person.id].gender) item.checked = true;
  });
  hobby.forEach((item) => {
    personLists[person.id].hobby.forEach((ele) => {
      if (item.id === ele) item.checked = true;
    });
  });
}

const addEventToPerson = () => {
  const persons = document.getElementsByClassName("person");
  // Add click event listener for div.person
  Array.from(persons).forEach((person) => {
    person.addEventListener("click", () => bindingData(person), false);
  });
};

const removeEventToPerson = () => {
  const persons = document.getElementsByClassName("person");
  // Remove click event listener for div.person
  Array.from(persons).forEach((person) => {
    person.removeEventListener("click", () => bindingData(person), false);
  });
};

// Create render function
const renderPersons = (personLists) => {
  let renderPlacement = document.getElementById("person-lists");
  let renderContent = ``;

  personLists.forEach((person, index) => {
    renderContent += `
      <div class="col mb-3 person" id=${index}>
        <div
          class="text-center border border-light px-3 py-1 bg-secondary"
        >
          ${person.name}
        </div>
      </div>
    `;
  });

  renderPlacement.innerHTML = renderContent;

  addEventToPerson();
};

// Call when page is loading
renderPersons(personLists);
