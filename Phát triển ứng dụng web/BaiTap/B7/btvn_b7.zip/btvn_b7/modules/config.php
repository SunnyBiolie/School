<?php

define("HOST", "localhost");
define("DB", "db_pagination");
define("USER", "root");
define("PASSWORD", "");
define("ITEM_PER_PAGE", 4);