<div>
  <select name="" id="" onchange="showPostofUser(this.value)">
    <option value="">All users</option>
    <?php
    include_once __DIR__ . "/../controllers/controller.php";

    $controller = new Controller();

    $controller->renderListOptionUser();

    ?>
  </select>
</div>

<script>
  function showPostofUser(userId) {
    <?php $_GET['page'] = 1; ?>
    let userPath = userId ? ("&userId=" + userId) : "";
    let keywordPath = '<?php echo $_GET['keyword'] ? "&keyword=" . $_GET['keyword'] : ""; ?>';
    let link = "./views/content_tk.php?page=" + '<?php echo $_GET['page']; ?>' + keywordPath + userPath;

    console.log(link);

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 & this.status == 200) {
        document.querySelector(".content").innerHTML = this.responseText;
      }
    }
    xmlhttp.open('GET', link, true);
    xmlhttp.send();
  }
</script>