<?php

require_once __DIR__ . "/../controllers/controller.php";
$controller = new Controller();

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$page = is_numeric($page) ? $page : 1;
$from = ($page - 1) * ITEM_PER_PAGE;

$postCount = $controller->getPostCount();
$total = ceil($postCount/ITEM_PER_PAGE);

if (isset($_GET['user']))
  $result = excuteQuery($link, "select * from tbl_posts where userId = " . $_GET['user'] . " limit " . $from . ", " . ITEM_PER_PAGE);
else
  $result = excuteQuery($link, "select * from tbl_posts limit " . $from . ", " . ITEM_PER_PAGE);

while ($row = mysqli_fetch_assoc($result)) {
  echo "
    <div class='post-item'>
      <a href='chitiet.php?post=" . $row['id'] . "'>
        <div class='post-inner'>
          <h3>" . $row['title'] . "</h3>
          <p>" .  $row['userId'] . "</p>
        </div>
      </a>
    </div>
  ";
}

echo "<br/>";
echo "<div class='pager'>";
for ($i = 1; $i <= $total; $i++) {
  if ($i != $page)
    echo "<a href='?page=" . $i . (isset($_GET['user']) ? "&user=".$_GET['user']:"") ."'>$i</a>";
  else
    echo "<span>". $i ."</span>";
}
echo "</div>";

?>
<style>
  a {
    display: inline-block;
    box-sizing: border-box;
  }

  .post-item {
    background: rgba(0, 0, 0, 0.3);
    margin: 12px 8px;
  }
  .post-item:hover {
    background: rgba(0, 0, 0, 0.15);
  }
  .post-item > a {
    text-decoration: none;
    color: #000;
    width: 100%;
    padding: 16px;
  }

  .pager {
    text-align: center;
    background-color: #eee;
    padding: 12px 8px;
  }
  .pager > a, .pager > span {
    color: #6240b8;
    margin: 0 8px;
  }
  .pager > span {
    color: black;
    font-weight: bolder;
  }
</style>