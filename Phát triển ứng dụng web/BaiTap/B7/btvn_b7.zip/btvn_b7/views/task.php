<div class="col-8 bg-secondary"></div>
<form action="./" method="get" class="col-4">
  <input type="text" name="keyword" />
  <input type="submit" value="Tìm kiếm" />
</form>